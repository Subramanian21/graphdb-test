var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
//var users = {};

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {
  /*socket.on('newChat', (conversationId) => {
    console.log('New chat with conversationId' + conversationId + ' and socketId '+ socket.id);  
    users[conversationId] = socket.id;
    io.to(users[conversationId]).emit('respondMessage', 'Hi! I am Cora. Your digital Banking assistant. How can i help you?');
  });*/

  socket.on('textMessage', (msg) => {
    io.to(socket.id).emit('receivedMessage', msg.message);
    // Proccess intent and respond
    io.to(socket.id).emit('respondMessage', 'some response');
  });

  socket.on('disconnect', () => {
    console.log('user disconnected ' + socket.id);
  });
});

http.listen(3000, () => {
  console.log('listening on *:3000');
});