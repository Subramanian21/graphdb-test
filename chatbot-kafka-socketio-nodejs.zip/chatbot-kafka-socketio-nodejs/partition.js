var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var kafka = require('kafka-node');

app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());
app.use(express.static(__dirname + '/css'));

const kafka_chat_topic = 'cora-topic';
const web_partitions = [1, 2, 3];
const mobile_partitions = [4, 5, 6];
var Producer = kafka.Producer;
var Consumer = kafka.Consumer;
const client = new kafka.KafkaClient();

function keyHashCode(stringOrBuffer) {
    let hash = 0;
    if (stringOrBuffer) {
        const string = stringOrBuffer.toString();
        const length = string.length;

        for (let i = 0; i < length; i++) {
            hash = ((hash * 31) + string.charCodeAt(i)) & 0x7fffffff;
        }
    }
    return (hash === 0) ? 1 : hash;
};

var CustomPartitioner = function (partitions, key) {
    var index = 0;
    var partition = 1;
    if (key.includes('web')) {
        index = keyHashCode(key) % web_partitions.length;
        partition = web_partitions[index];
    } else if (key.includes('mobile')) {
        index = keyHashCode(key) % mobile_partitions.length;
        partition = mobile_partitions[index];
    }
    return partition;
};

const kafkaProducer = new Producer(client, {
        requireAcks: 1, // leader will write to its local log but will not wait for acknowledgement from followers
        partitionerType: 4 // Custom Partitioner
    },
    CustomPartitioner
);

const kafkaConsumerWeb = new Consumer(
    client,
    [{
        topic: kafka_chat_topic,
        partition: 0
    },
    {
        topic: kafka_chat_topic,
        partition: 1
    },
    {
        topic: kafka_chat_topic,
        partition: 2
    }], {
        autoCommit: true,
        groupId: 'web'
    }
);

/*const kafkaConsumerMobile = new Consumer(
    client,
    [{
        topic: kafka_chat_topic,
        partition: 3
    },
    {
        topic: kafka_chat_topic,
        partition: 4
    },
    {
        topic: kafka_chat_topic,
        partition: 5
    }], {
        autoCommit: true,
        groupId: 'mobile'
    }
);*/

// Load chat page
app.get('/web', (req, res) => {
    res.sendFile(__dirname + '/chatbot.html');
});

app.get('/mobile', (req, res) => {
    res.sendFile(__dirname + '/mobile.html');
});

// Endpoint to publish message to Kafka
app.post('/api/sendMsg', function (req, res) {
    var channel = req.header('cora-channel');
    var message = JSON.stringify(req.body);
    var msg = JSON.parse(message);
    payloads = [{
        topic: kafka_chat_topic,
        messages: message,
        attributes: 1,
        key: channel + '-' +msg.senderId
    }];
    kafkaProducer.send(payloads, function (err, data) {
        if (err) {
            console.log('kafka-producer -> broker update failed', err);
        } else {
            res.json(data);
        }
    });
});

kafkaProducer.on('ready', function () {
    console.log('Producer is ready');
});

kafkaProducer.on('error', function (err) {
    console.log('Kafka producer is in error state', err);
    res.status(500).json(err);
});

kafkaConsumerWeb.on('message', function (message) {
    console.log('inside web consumer');
    var msg = JSON.parse(message.value);
    console.log(msg);
    if (msg && msg.senderId) {
        io.to(msg.senderId).emit('receivedMessage', msg.message);
        // call broker, nlp engine and construct response according to channel
        io.to(msg.senderId).emit('respondMessage', 'test 123');
    }
});

kafkaConsumerWeb.on('error', function (err) {
    console.log('Kafka consumer web is in error state');
    console.log(err);
});

/*kafkaConsumerMobile.on('message', function (message) {
    console.log('inside mobile consumer');
    var msg = JSON.parse(message.value);
    console.log(msg);
    if (msg && msg.senderId) {
        io.to(msg.senderId).emit('receivedMessage', msg.message);
        // call broker, nlp engine and construct response according to channel
        io.to(msg.senderId).emit('respondMessage', 'test 123');
    }
});

kafkaConsumerMobile.on('error', function (err) {
    console.log('Kafka consumer mobile is in error state');
    console.log(err);
});*/


http.listen(3000, () => {
    console.log('Server listening on port 3000');
});