var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var kafka = require('kafka-node');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(__dirname + '/css'));

const kafka_chat_topic = 'cora-topic';
var Producer = kafka.HighLevelProducer,
    Consumer = kafka.Consumer,
    client = new kafka.KafkaClient(),
    kafkaProducer = new Producer(client),
    kafkaConsumer = new Consumer(
        client,
        [{ topic: kafka_chat_topic, partition: 1 }],
        { autoCommit: false }
    );


// Load chat page
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/chatbot.html');
});

// Endpoint to publish message to Kafka
app.post('/api/sendMsg', function (req, res) {
    var message = JSON.stringify(req.body);
    payloads = [
        { topic: kafka_chat_topic, messages: message, attributes: 1 }
    ];
    kafkaProducer.send(payloads, function (err, data) {
        if (err) {
            console.log('kafka-producer -> broker update failed');
        } else {
            res.json(data);
        }
    });
});

kafkaProducer.on('ready', function () {
    console.log('Producer is ready');
});

kafkaProducer.on('error', function (err) {
    console.log('Kafka producer is in error state', err);
    res.status(500).json(err);
});

kafkaConsumer.on('message', function (message) {
    var msg = JSON.parse(message.value);
    console.log(msg);
    if (msg && msg.senderId) {
        io.to(msg.senderId).emit('receivedMessage', msg.message);
        // call broker, nlp engine and construct response according to channel
        io.to(msg.senderId).emit('respondMessage', 'test 123');
    }
});

kafkaConsumer.on('error', function (err) {
    console.log('Kafka consumer is in error state');
    console.log(err);
});

http.listen(3000, () => {
    console.log('Server listening on port 3000');
});