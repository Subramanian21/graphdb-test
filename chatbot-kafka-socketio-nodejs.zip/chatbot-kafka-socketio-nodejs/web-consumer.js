var express = require('express');
var app = express();
var http = require('http').createServer(app);
var kafka = require('kafka-node');
var Consumer = kafka.Consumer;

const kafka_chat_topic = 'cora-topic';
const client = new kafka.KafkaClient();

const kafkaConsumer = new Consumer(
    client,
    [{
        topic: kafka_chat_topic,
        partition: 1
    },
    {
        topic: kafka_chat_topic,
        partition: 2
    },
    {
        topic: kafka_chat_topic,
        partition: 3
    }], {
        autoCommit: true
    }
);

kafkaConsumer.on('message', function (message) {
    var msg = JSON.parse(message.value);
    console.log(msg);
    if (msg && msg.senderId) {
        //io.to(msg.senderId).emit('receivedMessage', msg.message);
        // call broker, nlp engine and construct response according to channel
        //io.to(msg.senderId).emit('respondMessage', 'test 123');
    }
});

kafkaConsumer.on('error', function (err) {
    console.log('Kafka consumer is in error state');
    console.log(err);
});

http.listen(3100, () => {
    console.log('Consumer Server listening on port 3100');
});