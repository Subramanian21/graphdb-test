const { AssignerProtocol: {MemberAssignment, MemberMetadata}} = require('kafkajs')

function assign(name, partitions) {
    const partitionAssigner = ({ cluster }) => ({
        name: name,
        version: 1,
        async assign({ members, topics }) {
            console.log(members)
            const membersCount = members.length
            const sortedMembers = members.map(({ memberId }) => memberId).sort()
            const assignment = {}
    
            const topicsPartionArrays = topics.map(topic => {
                const partitionMetadata = cluster.findTopicPartitionMetadata(topic)
                return partitionMetadata.map(m => ({ topic: topic, partitionId: m.partitionId }))
            })
    
            const topicsPartitions = flatten(topicsPartionArrays)
    
            topicsPartitions.forEach((topicPartition, i) => {
                const assignee = sortedMembers[i % membersCount]
          
                if (!assignment[assignee]) {
                  assignment[assignee] = Object.create(null)
                }
          
                if (!assignment[assignee][topicPartition.topic]) {
                  assignment[assignee][topicPartition.topic] = []
                }

                if(partitions.includes(topicPartition.partitionId)) {
                    assignment[assignee][topicPartition.topic].push(topicPartition.partitionId)
                }
            })
    
            return Object.keys(assignment).map(memberId => ({
                memberId,
                memberAssignment: MemberAssignment.encode({
                  version: this.version,
                  assignment: assignment[memberId],
                }),
            }))
        },
        protocol({ topics }) {
            return {
              name: this.name,
              metadata: MemberMetadata.encode({
                version: this.version,
                topics,
              }),
            }
        }
    })

    return partitionAssigner
}

function flatten(arrays) {
  return [].concat.apply([], arrays)
}

exports.assign = assign;