const request = require('request-promise');
const axios = require('axios')
const { Kafka, logLevel, AssignerProtocol: {MemberAssignment, MemberMetadata}, PartitionAssigners: { roundRobin }} = require('kafkajs')
const kafka_topic = 'cora-events'
const web_partitions = [0, 1, 2]
const partitionAssigner = require('./partitionAssigner')
const io = require('socket.io-client');
var socket = io('http://localhost:8100', {transports: ['websocket']});
const kafka = new Kafka({
    logLevel: logLevel.INFO,
    clientId: 'cora-app',
    brokers: ['localhost:9092']
})

const consumer = kafka.consumer({
    groupId: 'cora-events-web-consumer',
    partitionAssigners: [
        partitionAssigner.assign('EventsWebPartitionAssigner', web_partitions),
        roundRobin
    ]
})

var Cloudant = require('@cloudant/cloudant')
var cloudant = Cloudant({account: '43f20879-4157-41f8-8391-2b70ae4b1e8d-bluemix', password: '42c05155a4a8d22fefdf70256b91cf42680862871c1a57fdf1c1dec490e36332', requestDefaults: { "proxy": "http://europa%5Cthirusd:Hasini04@fm-eu-lon-proxy.fm.rbsgrp.net:8080" }}, function (err, cloudant) {
    if (err) {
        console.log('Failed to initialize Cloudant: ' + err);
    } else {
        console.log('successfully intialized cloudant: ');
        return cloudant;
    }
});
var db = cloudant.use('ccm-conv-history');

function saveDocument(id, data) {
    if (id === undefined) {
        // Generated random id
        id = '';
    }
    db.insert({data: data, timestamp: Date.now()}, id, function(err, doc) {
        if (err) {
            console.log('Error saving document '+err);
        } else {
            console.log('doc saved');
        }
    });
}


const run = async () => {
    await consumer.connect()
    await consumer.subscribe({ topic: kafka_topic })
    await consumer.run({
        eachMessage: async ({ topic, partition, message }) => {
            /*console.log({
                key: message.key.toString(),
                value: message.value.toString(),
                headers: message.headers,
            })*/
            var msg = JSON.parse(message.value.toString());
            if (msg && msg.senderId && msg.state) {
                //console.log(JSON.stringify(msg))
                saveDocument(null, msg)
                if(msg.state == 'USER_INPUT') {
                    var response = await callBot(msg,true);
                    //var botResponse = 'Response from bot';
                    publishEvent(msg.senderId, 'BOT_RESPONSE', JSON.stringify(response))
                } else if(msg.state == 'BOT_RESPONSE') {
                    socket.emit('channelResponse', JSON.stringify(msg));
                } else if(msg.state == 'NEW_CONNECTION') {
                    var botResponse = 'Hi! I am Cora, Your digital banking assistant. How can i help you?';
                    publishEvent(msg.senderId, 'BOT_RESPONSE', botResponse)
                }
            }
        },
    })
}

function publishEvent(senderId, state, message) {
    axios
        .post('http://localhost:3100/api/storeEvent', {
            senderId: senderId,
            state: state,
            message: message
        }, {
            headers: {
                'cora-channel': 'web'
            }
        })
        .then(res => {
            console.log('status code: '+ res.status + ', data: '+ JSON.stringify(res.data))
        })
        .catch(error => {
            console.error(error)
        })
}

async function callBot(msg) {
    let body = {
        "conversationId": msg.senderId,
        "message": {
            "text": msg.message
        },
        "cin": "34534543",
        "brand": "RBS",
        "user": "34554560jaya",
        "authenticated": false
    }

    let options = {
        method: 'POST',
        uri: 'https://luvo-ivr-botmaster.eu-gb.mybluemix.net/REST/LUVORest',
        headers: {
            'Content-Type': 'application/json',
            'x-client-id': 'f3KR6S73-PT08-qqUs-ODI7-uXGCJebnXQkA',
            'x-client-secret': 'aRkobKkOb5ZHpn8ml3cunVQgjFDDyes5Z8HcEW1E0qCxMTvZ12'
        },
        body: body,
        json: true,
        simple: false,
        rejectUnauthorized: false
    }

    const resp = await request(options);
    return resp;
}

// Start Kafka Consumer
run().catch(e => console.log(`Error starting events consumer ${e.stack}`))