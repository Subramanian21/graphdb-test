var express = require('express');
var app = express();
var http = require('http').createServer(app);
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');

app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());
app.use(express.static(__dirname + '/static'));

app.get('/login', (req, res) => {
    res.sendFile(__dirname + '/static/login.html');
});

app.get('/landing', (req, res) => {
    res.sendFile(__dirname + '/static/landing-page.html');
});

app.post('/api/authenticate', function (req, res) {
    var username = req.body.uname;
    var password = req.body.pwd;

    // authenticate any credentials
    var userData = {
        brand: "RBS",   
        dbid: "1408630654",     
        cin: "1431501956",
        bin: "1150450123",        
        blcin: "1765358997",
        ctype: "03"
    }

    var token = jwt.sign({
        exp: Math.floor(Date.now() / 1000) + (60 * 60), // Expiers in 1hr
        data: userData
    }, 'passw0rd');
    
    res.cookie('authtoken', token, {
        httpOnly: false,
        maxAge: 3600000
    })
    res.redirect('/landing')
});

http.listen(9091, () => {
    console.log('Web Application listening on port 9091');
});