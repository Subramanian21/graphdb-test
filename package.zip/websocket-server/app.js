const axios = require('axios')
const jwt = require('jsonwebtoken');
const express = require('express');
const app = express();
const httpServer = require('http').Server(app);
const io = require("socket.io")(httpServer, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    },
    transports: ['websocket']
});
const DeviceDetector = require("device-detector-js");
const deviceDetector = new DeviceDetector();

function publishEvent(senderId, state, message) {
    axios
        .post('http://localhost:3100/api/storeEvent', {
            senderId: senderId,
            state: state,
            message: message
        }, {
            headers: {
                'cora-channel': 'web'
            }
        })
        .then(res => {
            console.log('status code: '+ res.status + ', data: '+ JSON.stringify(res.data))
        })
        .catch(error => {
            console.error(error)
        })
}

const setDisconnectTimeout = (socket) => {
    socket.disconnectTimeout = setTimeout(() => {
        // token is not sent from the user within x seconds
        console.log("Client does not re-auth within the specific time, disconnect")
        socket.disconnect(true);
    }, 1 * 60 * 1000);
}

const setAuthExpireTimeout = (socket, tokenExpireIn) => {
    socket.authExpireTimeout = setTimeout(() => {
        console.log("Last submitted token expired, need to reauth")
        // rquest the user to reauthenticate
        socket.emit('token_reauth');
        // set the logoutTimeout, if client don't provide new jwt, disconnect
        setDisconnectTimeout(socket);
    }, tokenExpireIn);
}

function getVistitorInfo(handshake) {
    //console.log(JSON.stringify(handshake))
    const agent = deviceDetector.parse(handshake.headers['user-agent']);
    if(handshake.headers['user-agent'] === undefined) {
        return null
    }
    return {
        raw : handshake.headers['user-agent'],
        device : agent.device,
        os: agent.os,
        client: agent.client,
        ipAddess: handshake.address,
        origin: handshake.headers['origin']
    }
}

function getCustomerInfo(data) {
    return {
        customerType : data.ctype,
        customerId : data.brand + "-" + data.dbid + "-" + data.cin + "-" + data.bin + "-" + data.blcin
    }
}

io.on('connection', (socket) => {
    console.log('New socket connected ' + socket.id)
    const visitorInfo = getVistitorInfo(socket.handshake)
    if(visitorInfo) {
        publishEvent(socket.id, 'NEW_CONNECTION', visitorInfo)
    } else {
        socket.isServer = true
    }

    socket.on('authenticate', (data) => {
        // validtate the token from client and set the decoded token in the socket
        jwt.verify(data.token, 'passw0rd', function (err, decoded) {
            if (err) {
                console.log("Invalid token");
                io.to(socket.id).emit('token_error', err);
            } else {
                console.log('decoded token' + JSON.stringify(decoded));
                socket.decoded_token = decoded;
                publishEvent(socket.id, 'AUTHENTICATED', getCustomerInfo(decoded.data))

                // if the user re-authenticate successfully, don't disconnect
                if(socket.disconnectTimeout) {
                    clearTimeout(socket.disconnectTimeout);
                }

                // create new reauthTimeout
                const tokenExpireIn = decoded.exp * 1000 - Date.now();
                console.log('token will expire in ', (tokenExpireIn / 1000) + ' seconds');
                socket.authExpireTimeout = setAuthExpireTimeout(socket, tokenExpireIn);
            }
        });
    });

    socket.on('newMessage', (data) => {
        if(socket.decoded_token) {
            console.log('I am authenticated')
        } else {
            console.log('I am un-authenticated')
        }
        publishEvent(socket.id, 'USER_INPUT', data.message)
    });

    // Disconnect Event Handler
    socket.on('disconnect', () => {
        console.log('user disconnected ' + socket.id);
        if(socket.isServer === undefined) {
            publishEvent(socket.id, 'DISCONNECTED', {})
        }
    });

    socket.on('channelResponse', (message) => {
        var msg = JSON.parse(message);
        console.log(msg)
        if (msg && msg.senderId) {
            io.to(msg.senderId).emit('respondMessage', msg.message);
        }
    });
});

httpServer.listen(8100, () => {
    console.log('Websocket Server listening on port 8100');
});