var express = require('express');
var app = express();
var http = require('http').createServer(app);
var bodyParser = require('body-parser');
var io = require('socket.io')(http);

app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());
app.use(express.static(__dirname + '/static/css'));

const kafkaProducer = require('./producer')

// Start Kafka Producer
kafkaProducer.run().catch(e => run().catch(e => console.log(`Error starting producer ${e.message}`)))

// Endpoint to publish message to Kafka
app.post('/api/sendMsg', async function (req, res) {
    var channel = req.header('cora-channel');
    var message = JSON.stringify(req.body);
    var msg = JSON.parse(message);
    const key = channel + '-' + msg.senderId

    var response = await kafkaProducer.sendMessage(key, message)
    res.json(response)
});

// Load chat page
app.get('/web', (req, res) => {
    res.sendFile(__dirname + '/static/web.html');
});

app.get('/mobile', (req, res) => {
    res.sendFile(__dirname + '/static/mobile.html');
});

var io = require('socket.io')(http, {
    cors: {
        origin: '*',
    }
});

http.listen(3000, () => {
    console.log('Contact Manager Server listening on port 3000');
});

io.on('connection', (socket) => {
    socket.on('disconnect', () => {
        console.log('user disconnected ' + socket.id);
    });   
    
    socket.on('channelResponse', (message) => {
        var msg = JSON.parse(message);
        if (msg && msg.senderId) {
            io.to(msg.senderId).emit('respondMessage', msg.message);
        }
    });
});