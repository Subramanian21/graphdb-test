const { Kafka, logLevel, AssignerProtocol: {MemberAssignment, MemberMetadata}, PartitionAssigners: { roundRobin }} = require('kafkajs')
const kafka_chat_topic = 'cora-topic';
const mobile_partitions = [3, 4, 5];
const partitionAssigner = require('./partitionAssigner')
var socket = require('socket.io-client')('http://localhost:3000');

const kafka = new Kafka({
    logLevel: logLevel.INFO,
    clientId: 'cora-app',
    brokers: ['localhost:9092']
})

const consumer = kafka.consumer({ groupId: 'cora-mobile',partitionAssigners: [
    partitionAssigner.assign('MobilePartitionAssigner', mobile_partitions),
    roundRobin
] })

const run = async () => {
    await consumer.connect()
    await consumer.subscribe({ topic: kafka_chat_topic })
    await consumer.run({
        eachMessage: async ({ topic, partition, message }) => {
            console.log({
                key: message.key.toString(),
                value: message.value.toString(),
                headers: message.headers,
            })
            var msg = JSON.parse(message.value.toString());
            if (msg && msg.senderId) {
                msg.message = "Response message from mobile bot";
                socket.emit('channelResponse', JSON.stringify(msg));
            }
        },
    })
}

// Start Kafka Consumer
run().catch(e => console.log(`Error starting consumer ${e.stack}`))

function flatten(arrays) {
    return [].concat.apply([], arrays)
}

exports.run = run;