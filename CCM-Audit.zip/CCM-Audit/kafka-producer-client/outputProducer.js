const { Kafka, logLevel, CompressionTypes} = require('kafkajs')
const kafka_chat_topic = 'cora-output-topic';
const web_partitions = [0, 1, 2];
const mobile_partitions = [3, 4, 5];

const kafka = new Kafka({
    logLevel: logLevel.INFO,
    clientId: 'cora-app',
    brokers: ['localhost:9092']
})

function keyHashCode(stringOrBuffer) {
    let hash = 0;
    if (stringOrBuffer) {
        const string = stringOrBuffer.toString();
        const length = string.length;

        for (let i = 0; i < length; i++) {
            hash = ((hash * 31) + string.charCodeAt(i)) & 0x7fffffff;
        }
    }
    return (hash === 0) ? 1 : hash;
};


// Custom Partitioner
const ChannelPartitioner = () => {
    return ({
        topic,
        partitionMetadata,
        message
    }) => {
        var index = 0;
        var partition = 0;
        if (message.key.includes('web')) {
            index = keyHashCode(message.key) % web_partitions.length;
            partition = web_partitions[index];
        } else if (message.key.includes('mobile')) {
            index = keyHashCode(message.key) % mobile_partitions.length;
            partition = mobile_partitions[index];
        }
        return partition;
    }
}

const producer = kafka.producer({
    createPartitioner: ChannelPartitioner
})

const run = async () => {
    await producer.connect()
}

const sendMessage = (key, message) => {
    return producer.send({
        topic: kafka_chat_topic,
        messages: [{
            key: key,
            value: message
        }],
        acks: 1,
        compression: CompressionTypes.GZIP
    })
}

exports.sendMessage = sendMessage;
exports.run = run;